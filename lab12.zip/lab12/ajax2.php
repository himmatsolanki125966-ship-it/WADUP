<!DOCTYPE html>
<html>
<head>
    <title>XMLHttpRequest Callback Example</title>
</head>
<body>

<h2>Read TXT File using XMLHttpRequest with Callback</h2>

<button onclick="loadDoc()">Load Data</button>

<!DOCTYPE html>
<html>
<head>
    <title>XMLHttpRequest Callback Example</title>
</head>
<body>
<p id="demo"></p>

<script>
function loadDoc() {
    var xhttp = new XMLHttpRequest();

    xhttp.onload = function() {
        document.getElementById("demo").innerHTML = xhttp.responseText;
    };

    xhttp.open("GET", "data.txt", true);
    xhttp.send();
}
</script>

</body>
</html>