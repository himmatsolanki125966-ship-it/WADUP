<!DOCTYPE html>
<html>
<head>
    <title>XMLHttpRequest with PHP</title>
</head>
<body>

<h2>Read TXT File using XMLHttpRequest</h2>

<button onclick="loadData()">Load Data</button>

<div id="result"></div>

<script>
function loadData() {
    var xhr = new XMLHttpRequest();

    xhr.open("GET", "data.txt", true);

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById("result").innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}
</script>

</body>
</html>